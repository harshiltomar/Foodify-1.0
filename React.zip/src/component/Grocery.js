import React from "react";

const Grocery = () => {
    return (
        <div className="grocery-container">
            <h1>
                Our Grocery online store, and we have a lot of child components inside this web page!!
                This Page is currently under maintainence, kindly wait for a while 
            </h1>
        </div>
    );
};

export default Grocery;
